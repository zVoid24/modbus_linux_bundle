#!/bin/bash
# Builds the SolSCADA golden rootfs. Run this AS ROOT on an Arch Linux build
# machine (a VM is fine — it doesn't need to match the kiosk hardware,
# except for GPU drivers, see note below).
#
# Usage: ./build-golden-image.sh /path/to/flutter/bundle
set -euo pipefail

BUNDLE_DIR="${1:?Usage: $0 /path/to/flutter/release/bundle}"
ROOTFS=/mnt/solscada-rootfs
OVERLAY_DIR="$(cd "$(dirname "$0")/.." && pwd)/overlay"

[ "$(id -u)" -eq 0 ] || { echo "Run as root"; exit 1; }

mkdir -p "$ROOTFS"

# --- Base system + everything the kiosk/technician sessions need ---------
# TODO: verify GPU driver package for your actual hardware (this defaults
# to Intel/generic; add xf86-video-amdgpu / nvidia as needed) and run
# `ldd` on your Flutter binary to catch any missing runtime libs.
pacstrap -c "$ROOTFS" \
    base linux linux-firmware sudo networkmanager \
    xorg-server xorg-xinit xorg-xset xorg-xsetroot \
    lightdm lightdm-gtk-greeter openbox \
    gtk3 mesa unclutter \
    firefox pcmanfm xterm \
    ttf-dejavu

# --- Copy in all the lockdown configs from overlay/ -----------------------
cp -a "$OVERLAY_DIR/etc/." "$ROOTFS/etc/"
cp -a "$OVERLAY_DIR/usr/." "$ROOTFS/usr/"
chmod +x "$ROOTFS"/usr/local/bin/*.sh

# --- Install the Flutter app ----------------------------------------------
mkdir -p "$ROOTFS/opt/solscada"
cp -a "$BUNDLE_DIR/." "$ROOTFS/opt/solscada/"
# adjust this to match your actual built executable name
chmod +x "$ROOTFS/opt/solscada"/*.bin 2>/dev/null || true

# --- AnyDesk ----------------------------------------------------------------
# AnyDesk isn't in the official Arch repos. Download their generic Linux
# tarball at build time and drop the binary in system PATH, rather than
# relying on an AUR helper (which would need to run as a non-root build
# user anyway — don't wire AUR access into the deployed image itself).
# curl -L -o /tmp/anydesk.tar.gz https://download.anydesk.com/linux/anydesk-<ver>-amd64.tar.gz
# tar -C "$ROOTFS/opt" -xzf /tmp/anydesk.tar.gz
# ln -sf /opt/anydesk/anydesk "$ROOTFS/usr/local/bin/anydesk"
echo "TODO: install AnyDesk into $ROOTFS — see comment above"

# --- Accounts ---------------------------------------------------------------
arch-chroot "$ROOTFS" /bin/bash -euxc '
    groupadd -f wheel

    useradd -m -G video,audio,input kiosk
    useradd -m -G video,audio,input,network technician
    useradd -m -G wheel,video,audio,network admin

    # Force these to be set interactively / via a provisioning step —
    # never ship a fleet with a hardcoded default password.
    passwd -l kiosk        # kiosk never logs in with a password (autologin only)
    passwd -e technician
    passwd -e admin

    systemctl enable lightdm NetworkManager
'

# --- Harden /home: no setuid binaries, no device nodes, and (optional)
# no exec of anything a technician downloads into their own home dir.
# Uncomment "noexec" only if you are sure technician never needs to run a
# script from their home directory — AnyDesk/Firefox/etc. all live in
# system paths already, so this is usually safe.
cat >> "$ROOTFS/etc/fstab" <<'EOF'
# /home        /home        none    bind,nosuid,nodev   0 0
EOF

echo "Golden rootfs built at $ROOTFS"
echo "Next: sudo ./make-squashfs.sh $ROOTFS solscada-v1.0.sfs"
