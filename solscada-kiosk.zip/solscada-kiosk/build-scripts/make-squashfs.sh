#!/bin/bash
# Compresses the golden rootfs into a single squashfs image — this is the
# artifact that changes between versions. Everything else in this repo
# (the installer ISO shell) stays the same across updates.
set -euo pipefail
ROOTFS="${1:-/mnt/solscada-rootfs}"
OUT="${2:-solscada-$(date +%Y%m%d).sfs}"

mksquashfs "$ROOTFS" "$OUT" -comp zstd -Xcompression-level 19 -noappend

echo "Built $OUT ($(du -h "$OUT" | cut -f1))"
echo "Next: copy this into installer/airootfs/root/solscada.sfs and run installer/build-iso.sh"
