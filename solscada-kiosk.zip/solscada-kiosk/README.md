# SolSCADA Kiosk Image — starter kit

A starting skeleton for turning your Flutter kiosk app into a locked-down,
mass-deployable Arch Linux image for 200 identical machines, built around
the workflow you described: one golden filesystem image, one installer ISO
that deploys it, and updates that are just "swap the image, rebuild the ISO."

**This is a working skeleton, not a finished, tested product.** Build and
verify it end-to-end on ONE machine before touching the other 199. The
parts most likely to need hardware-specific tweaks are flagged `TODO`
below.

## Architecture

```
                    ┌─────────────────────────────┐
                    │   LightDM (autologin)        │
                    └───────────────┬──────────────┘
                                     │
              ┌──────────────────────┴───────────────────────┐
              │                                                │
    ┌─────────▼──────────┐                         ┌───────────▼──────────┐
    │  kiosk session      │  Ctrl+Alt+F12 (hidden)  │  login screen        │
    │  - openbox, no      │ ───────────────────────▶│  (technician / admin │
    │    decorations       │                         │   type credentials) │
    │  - SolSCADA app,     │                         └───────────┬─────────┘
    │    fullscreen,        │                                     │
    │    restart loop        │                    ┌───────────────┴───────────────┐
    │  - no sudo, no shell    │                    │                                │
    └─────────────────────────┘         ┌──────────▼─────────┐         ┌───────────▼──────────┐
                                          │ technician session   │         │ admin (full desktop,  │
                                          │ browser/files/       │         │ full sudo — you use   │
                                          │ AnyDesk/terminal.     │         │ this to maintain/     │
                                          │ NOT in wheel, no sudo │         │ update the fleet)     │
                                          └───────────────────────┘         └───────────────────────┘
```

The end user (the "ATM" experience) only ever sees the kiosk session. There
is no window border, no taskbar, no alt-tab, and VT-switching/Ctrl-Alt-Backspace
are disabled at the Xorg level — so there's nothing on screen or the
keyboard that closes it. If the app crashes, a restart loop in
`kiosk-start.sh` relaunches it within 2 seconds.

The **only** documented way off the kiosk screen is `Ctrl+Alt+F12`, which
just requests the LightDM greeter — it grants no privilege by itself. A
technician then has to actually authenticate to get anywhere.

## Directory layout

```
golden-image/overlay/   → files copied verbatim into the golden rootfs
                          (sudoers, polkit, Xorg, LightDM, session scripts,
                          openbox configs for both sessions)
build-scripts/          → build-golden-image.sh, make-squashfs.sh
installer/               → archiso profile that produces the installer ISO
```

## Build workflow

1. **Build the golden rootfs** (on an Arch build machine or VM — doesn't
   need to match kiosk hardware except for GPU drivers):
   ```
   sudo build-scripts/build-golden-image.sh /path/to/flutter/release/bundle
   ```
   This pacstraps a base system, copies in every lockdown config from
   `golden-image/overlay/`, drops your Flutter bundle into `/opt/solscada`,
   and creates the three accounts (`kiosk`, `technician`, `admin`).

   **TODOs inside this script**: GPU driver package for your actual
   hardware, exact Flutter binary name/path, AnyDesk install (their
   official tarball, not AUR — see comment in the script), and setting
   real passwords for `technician`/`admin` before shipping.

2. **Compress it**:
   ```
   sudo build-scripts/make-squashfs.sh /mnt/solscada-rootfs solscada-v1.0.sfs
   ```

3. **Build the installer ISO**:
   ```
   cp solscada-v1.0.sfs installer/airootfs/root/solscada.sfs
   installer/build-iso.sh
   ```
   Before your first build, diff `installer/profiledef.sh` against
   `/usr/share/archiso/configs/releng/profiledef.sh` on your actual build
   machine — archiso's schema has changed across releases, and this file
   is a best-effort starting point, not a guaranteed-current spec.

4. **Write it to USB and deploy**:
   ```
   sudo dd if=installer/out/solscada-installer-*.iso of=/dev/sdX bs=4M status=progress oflag=sync
   ```
   Boot each of the 200 machines from that USB. `install.sh` auto-detects
   the disk, gives a 10-second countdown (your only abort window), then
   partitions, extracts the image, installs the bootloader, and reboots —
   no typed input needed.

## Updating to v1.1

Exactly the plan you had in mind:
1. Update the Flutter bundle / packages in the golden rootfs, rebuild it
   with `build-golden-image.sh`.
2. `make-squashfs.sh` → `solscada-v1.1.sfs`.
3. Drop it into `installer/airootfs/root/solscada.sfs`, rebuild the ISO.
4. Reflash. Since this is a full-disk reinstall rather than an in-place
   patch, there's no drift between machines to debug — every unit ends up
   byte-identical.

If you later want lighter app-only updates without a full reflash (e.g.
just the Flutter bundle changed, not the OS layer), an `admin` account with
sudo could push a new bundle to `/opt/solscada` directly over AnyDesk or a
network share — worth adding once the fleet is live, not before.

## Things to verify before trusting this on real hardware

- **GPU drivers** — pick the right one for your actual kiosk hardware in
  `build-golden-image.sh`, or graphics may not come up at all.
- **Flutter runtime deps** — run `ldd` on your built binary and make sure
  every `.so` it needs is pulled in by the packages listed.
- **Touchscreen vs mouse/keyboard** — if it's touch-only, the technician
  hotkey is moot unless there's a keyboard attached for maintenance. Worth
  deciding now whether technicians carry a USB keyboard, or whether you
  want an on-screen gesture instead.
- **Physical access to the hidden hotkey** — the whole technician-boundary
  model assumes a member of the public can't reach a keyboard. If the
  kiosk exposes one, Ctrl+Alt+F12 is trivially discoverable; consider a
  keyboard-less deployment or physically securing/removing it.
- **`/home` noexec** — commented out in the build script; enable it if you
  want to guarantee technician can't run anything they've downloaded into
  their own home directory.
