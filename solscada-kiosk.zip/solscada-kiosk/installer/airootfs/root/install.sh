#!/bin/bash
# SolSCADA unattended installer.
# Runs inside the archiso live environment. Wipes the target disk and lays
# down the golden image (solscada.sfs, sitting alongside this script on the
# ISO). Designed to be run 200 times with zero typed input beyond plugging
# in the USB — a short countdown is the only safety net against wiping the
# wrong box.
set -euo pipefail
LOG=/root/install.log
exec > >(tee -a "$LOG") 2>&1

echo "=== SolSCADA installer ==="

# Assumes one disk per machine (true for your 200 identical units). If a
# unit ever has more than one disk, this picks the first one — sanity
# check DISK below before trusting it on new hardware.
DISK=$(lsblk -dpno NAME,TYPE | awk '$2=="disk"{print $1; exit}')
echo "Target disk: $DISK"

echo "Installing to $DISK in 10 seconds. Unplug/power off now to abort."
for i in $(seq 10 -1 1); do printf "\r%2d..." "$i"; sleep 1; done
echo

# --- Partition: 512MiB ESP + rest as root ext4 -----------------------------
parted -s "$DISK" -- mklabel gpt \
    mkpart ESP fat32 1MiB 513MiB set 1 esp on \
    mkpart root ext4 513MiB 100%

if [[ "$DISK" == *nvme* ]]; then
    ESP="${DISK}p1"; ROOT="${DISK}p2"
else
    ESP="${DISK}1"; ROOT="${DISK}2"
fi

mkfs.fat -F32 "$ESP"
mkfs.ext4 -F "$ROOT"

mount "$ROOT" /mnt
mkdir -p /mnt/boot
mount "$ESP" /mnt/boot

# --- Lay down the golden image ---------------------------------------------
echo "Extracting golden image..."
unsquashfs -f -d /mnt /root/solscada.sfs

genfstab -U /mnt >> /mnt/etc/fstab

# --- Bootloader --------------------------------------------------------------
arch-chroot /mnt bootctl install
cat > /mnt/boot/loader/loader.conf <<'EOF'
default solscada.conf
timeout 0
console-mode max
EOF
ROOT_UUID=$(blkid -s UUID -o value "$ROOT")
cat > /mnt/boot/loader/entries/solscada.conf <<EOF
title   SolSCADA
linux   /vmlinuz-linux
initrd  /initramfs-linux.img
options root=UUID=${ROOT_UUID} rw quiet
EOF

echo "=== Install complete. Rebooting in 5s. ==="
sleep 5
umount -R /mnt
reboot
