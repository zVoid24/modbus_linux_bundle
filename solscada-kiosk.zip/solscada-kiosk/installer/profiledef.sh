#!/usr/bin/env bash
# Archiso profile definition for the SolSCADA installer ISO.
#
# IMPORTANT: archiso's profiledef.sh schema has shifted across releases.
# Before relying on this, run:
#   cp -r /usr/share/archiso/configs/releng/* installer/
# on your actual build machine and diff it against this file, folding in
# any fields that version expects. Treat this as a starting point, not a
# guaranteed-current spec.

iso_name="solscada-installer"
iso_label="SOLSCADA_$(date +%Y%m)"
iso_publisher="SolSCADA"
iso_application="SolSCADA Kiosk Installer"
iso_version="$(date +%Y.%m.%d)"
install_dir="solscada"
buildmodes=('iso')
bootmodes=(
  'bios.syslinux.mbr'
  'bios.syslinux.eltorito'
  'uefi-x64.systemd-boot.esp'
  'uefi-x64.systemd-boot.eltorito'
)
arch="x86_64"
pacman_conf="pacman.conf"
airootfs_image_type="squashfs"
airootfs_image_tool_options=('-comp' 'zstd' '-Xcompression-level' '19')

file_permissions=(
  ["/root/install.sh"]="0:0:755"
)
