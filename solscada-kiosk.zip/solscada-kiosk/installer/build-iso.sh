#!/bin/bash
# Builds the installer ISO from this profile. Requires archiso to be
# installed on the build machine (pacman -S archiso).
#
# Before running: copy the squashfs you built with make-squashfs.sh to
#   installer/airootfs/root/solscada.sfs
set -euo pipefail
PROFILE_DIR="$(cd "$(dirname "$0")" && pwd)"
WORK_DIR=/tmp/archiso-work
OUT_DIR="$PROFILE_DIR/out"

if [ ! -f "$PROFILE_DIR/airootfs/root/solscada.sfs" ]; then
    echo "Missing $PROFILE_DIR/airootfs/root/solscada.sfs"
    echo "Run build-scripts/make-squashfs.sh first and copy the output here."
    exit 1
fi

sudo mkarchiso -v -w "$WORK_DIR" -o "$OUT_DIR" "$PROFILE_DIR"
echo "ISO built in $OUT_DIR — write it to USB with:"
echo "  sudo dd if=$OUT_DIR/solscada-installer-*.iso of=/dev/sdX bs=4M status=progress oflag=sync"
